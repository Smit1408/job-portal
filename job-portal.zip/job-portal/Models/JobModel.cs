﻿// JobModel.cs
using System;

public class JobModel
{
    public string Id { get; set; }
    public UserModel User { get; set; }
    public string Company { get; set; }
    public decimal Salary { get; set; }
    public DateTime JobDeadline { get; set; }
    public string Title { get; set; }
}

public class UserModel
{
    public string Name { get; set; }
}
