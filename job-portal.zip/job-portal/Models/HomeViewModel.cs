﻿// Models/HomeViewModel.cs
namespace JobPortal.Models
{
    public class HomeViewModel
    {
        public bool IsLoading { get; set; }
    }
}
