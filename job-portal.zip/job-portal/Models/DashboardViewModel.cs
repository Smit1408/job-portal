﻿namespace job_portal.Models
{
    public class DashboardViewModel
    {
        public List<AppliedJob> AppliedJobs { get; set; }
        public List<BookmarkedJob> BookmarkedJobs { get; set; }
    }

    public class AppliedJob
    {
        // Define properties for applied jobs
    }

    public class BookmarkedJob
    {
        // Define properties for bookmarked jobs
    }
}
