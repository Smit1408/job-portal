﻿namespace job_portal.Models
{
    public class PostedJob
    {
        public string Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Company { get; set; }
        public decimal Salary { get; set; }
        public DateTime JobDeadline { get; set; }
        public string Title { get; set; }
    }
}