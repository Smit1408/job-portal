﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using job_portal.Models;
using Microsoft.AspNetCore.Mvc;


namespace job_portal.Controllers
{
    public class PostedJobsController : Controller
    {
        public IActionResult Index()
        {
            // Here you fetch the data from your backend service
            List<PostedJob> postedJobs = new List<PostedJob>();
            // Populate postedJobs with data fetched from your backend

            return View(postedJobs);
        }

        // You can have other actions like DetailPostedJob, JobDetails, etc.
    }
}
