﻿
using job_portal.Models;
using Microsoft.AspNetCore.Mvc;


namespace job_portal.Controllers
{
    public class PostJobController : Controller
    {
        public IActionResult Index()
        {
            
            return View();
        }
    }
}
