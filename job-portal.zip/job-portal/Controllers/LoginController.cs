﻿using Microsoft.AspNetCore.Mvc;

public class LoginController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(User user)
    {
        // Your login logic here
        if (IsValidUser(user))
        {
            // If user is valid, redirect to home page
            return RedirectToAction("Index", "Home");
        }
        else
        {
            // If user is not valid, return to login page with error message
            ModelState.AddModelError(string.Empty, "Invalid email or password.");
            return View("Index", user);
        }
    }

    private bool IsValidUser(User user)
    {
        // Dummy validation logic, replace with your actual logic (e.g., database check)
        return user.Email == "example@example.com" && user.Password == "password";
    }
}
