﻿using Microsoft.AspNetCore.Mvc;

public class RegisterController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(RegisterModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        // Your registration logic here
        // This is where you would save the user to your database or perform any other necessary actions

        TempData["SuccessMessage"] = "Registration successful. Please log in.";

        return RedirectToAction("Login", "Auth");
    }
}
