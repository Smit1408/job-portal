﻿using Microsoft.AspNetCore.Mvc;

namespace job_portal.Controllers
{
    public class DisplayJobsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
